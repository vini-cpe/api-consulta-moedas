# Análise de Dados com Python e SQL

Análise de base de dados com Pandas, SQLite e visualização com Matplotlib.