import pandas as pd
import sqlite3
import matplotlib.pyplot as plt

# Dados fictícios de vendas
data = {
    'produto': ['A', 'B', 'C', 'A', 'B', 'C'],
    'quantidade': [10, 20, 15, 5, 7, 10],
    'preco': [100, 150, 200, 100, 150, 200]
}

df = pd.DataFrame(data)
df['total'] = df['quantidade'] * df['preco']

# SQLite
conn = sqlite3.connect('vendas.db')
df.to_sql('vendas', conn, if_exists='replace', index=False)

# Consulta
consulta = pd.read_sql('SELECT produto, SUM(total) as total_vendido FROM vendas GROUP BY produto', conn)
print(consulta)

# Gráfico
consulta.plot(kind='bar', x='produto', y='total_vendido', legend=False)
plt.title('Total Vendido por Produto')
plt.ylabel('R$')
plt.tight_layout()
plt.savefig('grafico.png')
plt.show()
