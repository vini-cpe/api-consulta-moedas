# API de Consulta de Moedas

Uma API simples usando Flask que retorna a cotação de moedas em tempo real.