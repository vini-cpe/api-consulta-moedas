# Dashboard com Streamlit

Um painel interativo com dados usando Python e Streamlit.