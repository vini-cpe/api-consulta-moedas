import streamlit as st
import pandas as pd

st.title('Dashboard de Vendas')

data = {
    'produto': ['A', 'B', 'C'],
    'vendas': [1500, 2300, 1200]
}

df = pd.DataFrame(data)

st.bar_chart(df.set_index('produto'))

st.write("Tabela de dados:")
st.dataframe(df)
