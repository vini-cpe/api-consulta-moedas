# Sistema de Login com Flask

Aplicação web com login e cadastro de usuários usando Flask e SQLite.