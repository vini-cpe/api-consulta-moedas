from flask import Flask, request, redirect, session
import sqlite3
import hashlib

app = Flask(__name__)
app.secret_key = 's3cr3t'

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form['username']
        pwd = hash_password(request.form['password'])
        conn = sqlite3.connect('users.db')
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE username=? AND password=?", (user, pwd))
        if cur.fetchone():
            session['username'] = user
            return redirect('/painel')
        return "Login inválido!"
    return """
    <form method='POST'>
        Usuário: <input type='text' name='username'><br>
        Senha: <input type='password' name='password'><br>
        <input type='submit' value='Entrar'>
    </form>
    """

@app.route('/painel')
def painel():
    if 'username' in session:
        return f"Bem-vindo, {session['username']}!"
    return redirect('/')

if __name__ == '__main__':
    conn = sqlite3.connect('users.db')
    conn.execute("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)")
    conn.commit()
    conn.close()
    app.run(debug=True)
